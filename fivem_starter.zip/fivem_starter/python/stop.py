#-*- coding: utf-8 -*-

import os
os.system("taskkill /f /im FXServer.exe")