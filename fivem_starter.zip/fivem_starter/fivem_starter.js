const Discord = require("discord.js");
const { Client, Intents } = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS] });
const disbut = require('discord-buttons');
disbut(client);
const spawn = require('child_process').spawn;
const MySQL = require('mysql');

var connect = MySQL.createConnection({
    host: "localhost",
    port: 3306,
    user: "root",
    password: "",
    database: "데이터베이스 이름"
})

const token = "봇토큰";
const prefix = "/"

client.on('ready', async () => {

})

client.on('message', async message => {
    if (message.author.bot) return

    const cha = "채널아이디";

    const embed = new Discord.MessageEmbed()
    .setThumbnail(message.guild.iconURL())
    .setFooter("테스트서버에 오신걸 환영합니다.", message.guild.iconURL())

    if (message.content.startsWith(prefix + "서버시작")) {
        const result = spawn('python', ['python/start.py']);
        result.stderr.on('data', function(data) { return console.log(data); });

        await message.delete()
        await message.channel.send(`> [**서버제어**]\n\n> 관리자: ${message.author}\n> 제어: 서버온`)

        embed.setTitle(`서버 온라인 / Server Online`, message.guild.iconURL())
        embed.setDescription(`테스트 서버가 정상적으로 실행되었습니다. \n\n **입장방법** \n\n 밑 \`서버입장\` 버튼을 눌러주시면됩니다. \n\n혹은 파이브엠에서 F8을 눌러 \`connect cfx.re/join/ea7bkd\`를 입력후 입장해주세요!`)
        embed.setColor("GREEN")

        const button = new disbut.MessageButton()
        .setStyle("url")
        .setURL("https://cfx.re/join/ea7bkd")
        .setLabel("서버입장")

        await message.guild.channels.cache.get(cha).send({embed: embed, component: button}).then((m) => {
            connect.query(`UPDATE reboot SET messageid=${m.id}`)
        })
    } else if (message.content.startsWith(prefix + "서버리붓")) {
        connect.query(`SELECT * FROM reboot`, async function(err, rows) {
            let channel = await message.guild.channels.cache.get(cha)
            let messages = await channel.messages.fetch(rows[0].messageid)

            await message.delete()
            await message.channel.send(`> [**서버제어**]\n\n> 관리자: ${message.author}\n> 제어: 서버리붓`)
    

            const result = spawn('python', ['python/stop.py']);
            result.stdout.on('data', function(data) { console.log("서버가 종료되었습니다."); }); 
            result.stderr.on('data', function(data) { console.log("이미 서버가 종료되어있습니다."); });
            embed.setTitle(`서버 리붓 / Server Reboot`, message.guild.iconURL())
            embed.setDescription(`테스트 서버가 리붓중입니다. \n\n잠시만 기다려주세요!`)
            embed.setColor("YELLOW")
            await messages.edit(embed)
    
            const results = spawn('python', ['python/start.py']);
            results.stdout.on('data', function(data) { console.log(data); }); 
            results.stderr.on('data', function(data) { console.log(data); });
    
            embed.setTitle(`서버 온라인 / Server Online`, message.guild.iconURL())
            embed.setDescription(`테스트 서버가 정상적으로 실행되었습니다. \n\n **입장방법** \n\n 밑 \`서버입장\` 버튼을 눌러주시면됩니다. \n\n혹은 파이브엠에서 F8을 눌러 \`connect cfx.re/join/ea7bkd\`를 입력후 입장해주세요!`)
            embed.setColor("GREEN")
    
            await sleep(5000)
            await messages.edit(embed)
        })
    } else if (message.content.startsWith(prefix + "서버정검")) {
        
    } else if (message.content.startsWith(prefix + "서버종료")) {
        const result = spawn('python', ['python/stop.py']);
        result.stderr.on('data', function(data) { return console.log("이미 서버가 종료되어있습니다."); });
        result.stdout.on('data', function(data) { console.log("서버가 종료되었습니다."); }); 

        await message.delete()
        await message.channel.send(`> [**서버제어**]\n\n> 관리자: ${message.author}\n> 제어: 서버오프`)

        embed.setTitle(`서버 오프라인 / Server Offline`)
        embed.setDescription(`테스트 서버가 정상적으로 종료되었습니다.`)
        embed.setColor("RED")

        connect.query(`SELECT * FROM reboot`, async function(err, rows) {
            let channel = await message.guild.channels.cache.get(cha)
            let messages = await channel.messages.fetch(rows[0].messageid)
            await messages.edit(embed)
        })
    }
})

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
};

client.login(token).then(async () => { console.log("로그인 됨")})